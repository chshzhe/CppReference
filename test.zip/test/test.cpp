#include <cstring>
#include <iostream>
using namespace std;
int test()
{
    int a = 0;
}

int main()
{
    int a = 0;
    bool dsdd;
    int b = 2;
    cout << "ww" << endl;
    cout << dsdd << endl;
    for (int i; i <= 100; i++)
    {
        cout << "wsdds" << endl;
        cin >> a;
        cout << a + 1 << endl;
    }
}